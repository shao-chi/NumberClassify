def train(data_dir):
    # train your model with images from data_dir
    # the following code is just a placeholder
    pass

def test(data_dir):
    # make your model give prediction for images from data_dir
    # the following code is just a placeholder
    return [1,3,4,5], [1,4,3,5]